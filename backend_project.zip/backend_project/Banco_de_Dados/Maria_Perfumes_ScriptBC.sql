
CREATE DATABASE Maria_Perfumes
USE Maria_Perfumes

-- 1. Tabela PESSOA
-- Tabela base para Cliente e Funcionario.
CREATE TABLE Pessoa (
    id INT PRIMARY KEY IDENTITY(1,1), -- Auto-incremento no SQL Server
    cpf VARCHAR(11) UNIQUE NOT NULL,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE,
    telefone VARCHAR(20)
);
GO

-- 2. Tabela MARCA
CREATE TABLE Marca (
    id INT PRIMARY KEY IDENTITY(1,1),
    nome VARCHAR(50) UNIQUE NOT NULL
);
GO

-- 3. Tabela PERFUME
CREATE TABLE Perfume (
    id INT PRIMARY KEY IDENTITY(1,1),
    nome VARCHAR(100) NOT NULL,
    descricao VARCHAR(MAX), -- Usando VARCHAR(MAX) para textos longos
    preco DECIMAL(10, 2) NOT NULL,
    marca_id INT NOT NULL,
    FOREIGN KEY (marca_id) REFERENCES Marca(id)
);
GO

-- 4. Tabela CLIENTE
-- Cliente herda atributos de Pessoa.
CREATE TABLE Cliente (
    id INT PRIMARY KEY,
    FOREIGN KEY (id) REFERENCES Pessoa(id)
);
GO

-- 5. Tabela FUNCIONARIO
-- Funcionario herda atributos de Pessoa.
CREATE TABLE Funcionario (
    id INT PRIMARY KEY,
    comissao DECIMAL(5, 2),
    FOREIGN KEY (id) REFERENCES Pessoa(id)
);
GO

-- 6. Tabela PERFUME_FALTA
CREATE TABLE Perfume_Falta (
    id INT PRIMARY KEY IDENTITY(1,1),
    nome VARCHAR(100) UNIQUE NOT NULL
);
GO

-- 7. Tabela COMPRA
-- Relacionamento N:1 com Cliente.
CREATE TABLE Compra (
    id INT PRIMARY KEY IDENTITY(1,1),
    valor_total DECIMAL(10, 2),
    cliente_id INT NOT NULL,
    FOREIGN KEY (cliente_id) REFERENCES Cliente(id)
);
GO

-- 8. Tabela CONTEM 
CREATE TABLE Contem (
    compra_id INT NOT NULL,
    perfume_id INT NOT NULL,
    qtd INT NOT NULL,
    preco DECIMAL(10, 2) NOT NULL,
    PRIMARY KEY (compra_id, perfume_id),
    FOREIGN KEY (compra_id) REFERENCES Compra(id),
    FOREIGN KEY (perfume_id) REFERENCES Perfume(id)
);
GO

-- 9. Tabela SOLICITA 
CREATE TABLE Solicita (
    funcionario_id INT NOT NULL,
    perfume_falta_id INT NOT NULL,
    PRIMARY KEY (funcionario_id, perfume_falta_id),
    FOREIGN KEY (funcionario_id) REFERENCES Funcionario(id),
    FOREIGN KEY (perfume_falta_id) REFERENCES Perfume_Falta(id)
);
GO

-- 10. Tabela SENTE 
CREATE TABLE Sente (
    cliente_id INT NOT NULL,
    perfume_falta_id INT NOT NULL,
    PRIMARY KEY (cliente_id, perfume_falta_id),
    FOREIGN KEY (cliente_id) REFERENCES Cliente(id),
    FOREIGN KEY (perfume_falta_id) REFERENCES Perfume_Falta(id)
);
GO

-- ***********************************
-- 1. INSERTS NA TABELA PESSOA (10 registros)
-- ***********************************
INSERT INTO Pessoa (cpf, nome, email, telefone)
VALUES
('11122233344', 'Ana Silva', 'ana.silva@email.com', '910001000'),    -- ID 1
('55566677788', 'Bruno Costa', 'bruno.costa@email.com', '910002000'),  -- ID 2
('99988877766', 'Carlos Mendes', 'carlos.mendes@email.com', '910003000'),-- ID 3
('44433322211', 'Diana Luz', 'diana.luz@email.com', '910004000'),    -- ID 4
('12345678900', 'Eduarda Souza', 'eduarda.souza@email.com', '910005000'),-- ID 5
('09876543210', 'F�bio Reis', 'fabio.reis@email.com', '910006000'),   -- ID 6
('10203040500', 'Gabriela Lima', 'gabriela.lima@email.com', '910007000'),-- ID 7
('60504030200', 'Hugo Viana', 'hugo.viana@email.com', '910008000'),    -- ID 8
('70809010200', 'Igor Rocha', 'igor.rocha@email.com', '910009000'),     -- ID 9
('30201090800', 'J�lia Alves', 'julia.alves@email.com', '910010000');   -- ID 10
GO

-- ***********************************
-- 2. INSERTS NA TABELA CLIENTE (5 registros)
-- ***********************************
-- IDs 1, 2, 5, 7, 10 da Pessoa s�o clientes
INSERT INTO Cliente (id)
VALUES
(1), -- Ana Silva
(2), -- Bruno Costa
(5), -- Eduarda Souza
(7), -- Gabriela Lima
(10); -- J�lia Alves
GO

-- ***********************************
-- 3. INSERTS NA TABELA FUNCIONARIO (5 registros)
-- ***********************************
-- IDs 3, 4, 6, 8, 9 da Pessoa s�o funcion�rios
INSERT INTO Funcionario (id, comissao)
VALUES
(3, 5.00),  -- Carlos Mendes
(4, 7.50),  -- Diana Luz
(6, 6.00),  -- F�bio Reis
(8, 4.50),  -- Hugo Viana
(9, 8.00);  -- Igor Rocha
GO

-- ***********************************
-- 4. INSERTS NA TABELA MARCA (4 registros)
-- ***********************************
INSERT INTO Marca (nome)
VALUES
('Chanel'),   -- ID 1
('Dior'),     -- ID 2
('Gucci'),    -- ID 3
('Giorgio Armani'); -- ID 4
GO

-- ***********************************
-- 5. INSERTS NA TABELA PERFUME (8 registros)
-- ***********************************
-- Marca IDs: 1=Chanel, 2=Dior, 3=Gucci, 4=Armani
INSERT INTO Perfume (nome, descricao, preco, marca_id)
VALUES
('Coco Mademoiselle', 'Oriental moderno, fresco e leve.', 650.00, 1), -- ID 1
('Sauvage', 'Fresco, amadeirado, e potente.', 580.00, 2),            -- ID 2
('Guilty', 'Floral e Oriental, para a mulher contempor�nea.', 450.00, 3), -- ID 3
('N�5', 'O cl�ssico atemporal de alde�dos e flores.', 700.00, 1),       -- ID 4
('Acqua di Gi�', 'Fresco, aqu�tico e amadeirado.', 400.00, 4),           -- ID 5
('Miss Dior', 'Floral e vibrante, uma ode ao amor.', 620.00, 2),        -- ID 6
('Flora', 'Floral doce e frutado, alegre e vibrante.', 480.00, 3),      -- ID 7
('Code', 'Oriental especiado, elegante e sedutor.', 510.00, 4);          -- ID 8
GO

-- ***********************************
-- 6. INSERTS NA TABELA PERFUME_FALTA (5 registros)
-- ***********************************
INSERT INTO Perfume_Falta (nome)
VALUES
('Jadore'),      -- ID 1
('Eternity'),    -- ID 2
('Light Blue'),  -- ID 3
('Good Girl'),   -- ID 4
('Invictus');    -- ID 5
GO

-- ***********************************
-- 7. INSERTS NA TABELA COMPRA (5 registros)
-- ***********************************
-- Cliente IDs: 1=Ana, 2=Bruno, 5=Eduarda, 7=Gabriela, 10=J�lia
INSERT INTO Compra (cliente_id, valor_total)
VALUES
(1, 1230.00), -- Compra 1: Ana
(2, 450.00),  -- Compra 2: Bruno
(5, 700.00),  -- Compra 3: Eduarda
(7, 1020.00), -- Compra 4: Gabriela (2x Code)
(10, 650.00); -- Compra 5: J�lia (1x Coco Mademoiselle)
GO

-- ***********************************
-- 8. INSERTS NA TABELA CONTEM (8 registros)
-- ***********************************
-- Perfume IDs: 1=Coco, 2=Sauvage, 3=Guilty, 4=N�5, 5=Acqua, 6=Miss Dior, 7=Flora, 8=Code
INSERT INTO Contem (compra_id, perfume_id, qtd, preco)
VALUES
(1, 1, 1, 650.00), -- Compra 1: 1 Coco Mademoiselle
(1, 2, 1, 580.00), -- Compra 1: 1 Sauvage
(2, 3, 1, 450.00), -- Compra 2: 1 Guilty
(3, 4, 1, 700.00), -- Compra 3: 1 N�5
(4, 8, 2, 510.00), -- Compra 4: 2 Code
(5, 1, 1, 650.00), -- Compra 5: 1 Coco Mademoiselle
(3, 6, 1, 620.00), -- Compra 3: 1 Miss Dior (valor_total da compra 3 deve ser 700+620=1320, ajuste se necess�rio)
(4, 5, 1, 400.00); -- Compra 4: 1 Acqua di Gi�
GO

-- ***********************************
-- 9. INSERTS NA TABELA SENTE (7 registros)
-- ***********************************
-- Cliente IDs: 1, 2, 5, 7, 10
-- Perfume_Falta IDs: 1=Jadore, 2=Eternity, 3=Light Blue, 4=Good Girl, 5=Invictus
INSERT INTO Sente (cliente_id, perfume_falta_id)
VALUES
(1, 1), -- Ana: Jadore
(1, 2), -- Ana: Eternity
(2, 1), -- Bruno: Jadore
(5, 3), -- Eduarda: Light Blue
(7, 4), -- Gabriela: Good Girl
(10, 5),-- J�lia: Invictus
(10, 1);-- J�lia: Jadore
GO

-- ***********************************
-- 10. INSERTS NA TABELA SOLICITA (5 registros)
-- ***********************************
-- Funcionario IDs: 3=Carlos, 4=Diana, 6=F�bio, 8=Hugo, 9=Igor
-- Perfume_Falta IDs: 1=Jadore, 3=Light Blue, 5=Invictus
INSERT INTO Solicita (funcionario_id, perfume_falta_id)
VALUES
(3, 1), -- Carlos: Jadore
(4, 3), -- Diana: Light Blue
(6, 1), -- F�bio: Jadore
(8, 5), -- Hugo: Invictus
(9, 3); -- Igor: Light Blue
GO

-- Seleciona todos os Clientes e seus dados completos da Pessoa
SELECT
    C.id AS Cliente_ID,
    P.nome AS Nome_Cliente,
    P.cpf AS CPF,
    P.telefone AS Telefone
FROM
    Cliente AS C
JOIN
    Pessoa AS P ON C.id = P.id;

-- Seleciona todos os Funcion�rios e seus dados completos
SELECT
    F.id AS Funcionario_ID,
    P.nome AS Nome_Funcionario,
    P.email AS Email,
    F.comissao AS Comissao_Percentual
FROM
    Funcionario AS F
JOIN
    Pessoa AS P ON F.id = P.id;
 -- Seleciona todos os Perfumes e seus dados completos
    SELECT
    Per.id AS Perfume_ID,
    Per.nome AS Nome_Perfume,
    Mar.nome AS Nome_Marca,
    Per.preco AS Preco,
    Per.descricao AS Descricao
FROM
    Perfume AS Per
JOIN
    Marca AS Mar ON Per.marca_id = Mar.id;

-- Seleciona todas as compras  e seus dados completos

    SELECT
    Comp.id AS Compra_ID,
    Pessoa.nome AS Nome_Cliente,
    Per.nome AS Perfume_Comprado,
    Mar.nome AS Marca_Perfume,
    Cont.qtd AS Quantidade,
    Cont.preco AS Preco_Unitario,
    Comp.valor_total AS Valor_Total_da_Compra
FROM
    Compra AS Comp
JOIN
    Cliente AS Cli ON Comp.cliente_id = Cli.id
JOIN
    Pessoa ON Cli.id = Pessoa.id
JOIN
    Contem AS Cont ON Comp.id = Cont.compra_id -- Tabela N:M
JOIN
    Perfume AS Per ON Cont.perfume_id = Per.id
JOIN
    Marca AS Mar ON Per.marca_id = Mar.id
ORDER BY
    Compra_ID;

    -- Seleciona todos os Perfumes em Falta Solicitados  e seus dados completos
    SELECT
    Pessoa.nome AS Nome_Funcionario,
    PF.nome AS Perfume_em_Falta_Solicitado
FROM
    Solicita AS Sol -- Tabela N:M
JOIN
    Funcionario AS F ON Sol.funcionario_id = F.id
JOIN
    Pessoa ON F.id = Pessoa.id
JOIN
    Perfume_Falta AS PF ON Sol.perfume_falta_id = PF.id;

    -- Seleciona todos os Perfumes em Falta Desejados  e seus dados completos

    SELECT
    Pessoa.nome AS Nome_Cliente,
    PF.nome AS Perfume_em_Falta_Desejado
FROM
    Sente AS Sen -- Tabela N:M
JOIN
    Cliente AS C ON Sen.cliente_id = C.id
JOIN
    Pessoa ON C.id = Pessoa.id
JOIN
    Perfume_Falta AS PF ON Sen.perfume_falta_id = PF.id;





